

function informacao(nome, sobrenome) {
  if (typeof nome === 'string' && typeof sobrenome === 'string') {
    console.log("ola" + nome + sobrenome)
  } else {
    alert('digite seu nome corretamente')
  }
}
informacao("leticia", "oliveira")
informacao(89, 160)

