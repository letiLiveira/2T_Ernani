//DECLARAÇÃO DE FUNÇÕES OU CRIAÇÃO DE FUNÇÕES
// function soma(n1, n2) {
//   if(typeof n1 === 'number' && typeof n2 === 'number'){
//     const res = n1 + n2
//   alert('0 resultado da soma é: ' + res)

//   }else{
//     alert('Por favor insira um número válido')
//   }

// }
// //INVOCAÇÃO DE FUNÇÕES OU CHAMADA DE FUNÇÕES
// soma("suco")
// soma(5, 15)
// soma(4, 50)

// CRIE UMA FUNÇÃO QUE RECEBA COMO PARAÊMETRO:
// NOME, ALTURA
// CHEQUE SE O NOME É DO TIPO TEXTO "STRING"
// CHEQUE SE A ALTURA É DO TIPO NUMÉRICO "NUMBER"
// SE AS DUAS CONDIÇOES FOREM VERDADEIRAS, IMPRIMA NO CONSOLE:
//"Olá + nome + "sua altura é" + "altura"


//DECLARAÇÃO DE FUNÇÕES OU CRIAÇÃO DE FUNÇÕES
function mensagem(nome, altura) {
  if (typeof nome === 'string') {
    if (typeof altura === 'number') {
      const mensagem = 'Olá' + nome + 'sua altura é' + altura
      alert(mensagem)

    }
  } else {
    alert('favor insira corretamente')
  }
}
mensagem("bruna", 1.64)
mensagem(89, 1.60)







