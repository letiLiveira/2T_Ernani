/**FUNÇÕES: são blocos de código que podem ser reaproveitados
 *Funções podem ou não ter nomes
 * Podem ou não receber parametros
  */

// crição ou declarar funções

 function dizOlá(nome) {
  //código 
    console.log('Olá!'+ nome)
 }
// chamando a função
dizOlá('Bruna')
dizOlá('Vitor')
dizOlá('Maria')

//adição
function somadoisNumeros(x,y) {
  const soma = x + y
  console.log(soma) 
}
somadoisNumeros(2,3)
somadoisNumeros(5,6)

//subtração
function subtracao(x,y) {
  const subtair = x - y
  console.log(subtair)
}
subtracao(10,7)
subtracao(20,8)

//multiplicação
function multiplicacao(x,y) {
  const multiplicar = x * y
  console.log(multiplicar)
}
multiplicacao(5,5)
multiplicacao(10,10)

//divisão
function divisao(x,y) {
  const dividir = x / y
  console.log(dividir)
}
divisao(10,2)
divisao(2,4)



