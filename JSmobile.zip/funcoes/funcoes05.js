// FUNÇÕES COM RETORNO
// SÃO FUNÇÕES QUE RETORNAM UM VALOR
// PROCESSADO
// PARA USO PODTERIOR

// const nome = 'leticia'
// function retornaDados(){
//   // código com retorno
//   return nome.toUpperCase()
//   console.log('testando...') // INALCANÇAVEL
//   // A PARTIR DESSA LINHA NÃO SERÁ EXECUTADO MAIS NADA  
// }
// const dados = retornaDados()
// console.log (dados)



/**
* CRIE UMA FUNÇÃO QUE RECEBA (nome, idade, cpf)
* RETORNE OS DADOS FORMATADOS COM UMA MENSAGEM COM TODOS OS DADOS
* ARMAZENE EM UMA VARIÁVEL E IMPRIMA ELA COM CONSOLE.LOG()
*/
//const dados = 'letícia', 16, 0123456789

function dadosPessoais(nome, idade, cpf){
  retrun 'Olá seu nome é ' + nome + 'sua idade é ' + idade + 'seu cpf é ' + cpf'
}
const dados = da
dosPessoais('leticia', 16, 0123456789)
console.log(dados)