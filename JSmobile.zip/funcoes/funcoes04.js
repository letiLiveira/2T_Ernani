
// CRIE UMA FUNÇÃO QUE:
/**
 * RECEBA UM NÚMERO COMO PARÂMETRO E CHEQUE SE (IF)
 *        N % 2 === 0 ENTÃO IMPRIMA "O NÚMERO" + N + "É PAR"
 * SENÃO (ELSE), IMPRIMA "O NÚMERO" + N + "É IMPAR!"
 */

function parOuImpar(n) {
if(typeof n === 'number'){
  if (n % 2 === 0) {
    alert("O número " + n + " é par")
  } else {
    alert("O número " + n + " é impar")
  }
} else {
  alert('Digite um número válido')
}
  
  
}
parOuImpar(985)
parOuImpar(6)
parOuImpar(80)
parOuImpar("sala")
parOuImpar(9)
