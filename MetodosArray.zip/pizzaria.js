let sabores = [] // CRIANDO UMA ARRAY VAZIA
let pedidos = 0

const cliente = prompt("Olá, qual é o seu nome?")
if(cliente){
  alert("Olá " + cliente + ", seja bem vindo(a)!")

  // LOOP DE REPETIÇÃO INFINITO (QUE RODA ENQUANTO A CONDIÇÃO FOR VERDADEIRA))
  while (pedidos < 3) {
    let sabor = prompt("🍕 Qual sabor de pizza você deseja?")
    if(sabor){
      sabores.push(sabor) // ENVIAR PARA NOSSA LISTA
      alert("pedido Recebido!")
      pedidos = pedidos + 1 // ACÚMULO DE VARIÁVEL

    }
    
  }
  // IMPRIMIR LISTA DE SABORES
  alert("Pedido finalizado! Olhe seu Log!")
  console.log("-------🍕PIZZARIA EMOJI🍕--------")
  console.log(sabores)
  console.log("---------------------------------")
  
} else {
  alert("Você não digitou seu nome! Por favor, tente novamente. 😢")
}
