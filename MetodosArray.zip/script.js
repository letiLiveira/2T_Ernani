// MÉTODOS DE ARRAY
const comidas = ['churrasco', 'pizza ']
comidas[3] = 'sushi' // MANUAL
comidas.push('berinjela') // EMPURRANDO UM VALOR PARA O FINAL DA LISTA
comidas.pop() // RETIRA UM VALOR DO FINAL DA LISTA
comidas.shift() // RETIRA UM VALOR DO ÍNICIO DA LISTA
comidas.unshift('lasanha') // INSERIR UM ITEM NO ÍNICIO DA LISTA

const tamanho = comidas.length
console.log("Existem " + tamanho + " itens na lista") // CONTAGEM O ITENS DA LISTA

console.log(comidas)