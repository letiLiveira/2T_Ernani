/**
 * DECLARAÇÃO DE VARIÁVEIS JAVASCRIPT:
 * identificador: nome da variável
 * valor: valor iniicial da variável;
 */
const nome = "Letícia"; //escopo global - mutável
const sobrenome = "De Oliveira"; //escopo em bloco - mutável
const idade = 17; //escopo em bloco - imutável
//REATRIBUINDO VALORES
//pet = "Gato";
//nome = "Nina";
//PI = 27.1;

//CONCATENAR OU JUNTAR VALORES
const DadosPessoais = nome + " " + sobrenome + " " + idade
const ano = 2024;
const anoNascimento = 2007
const idadeAtual = ano - anoNascimento


const num = 24
const ehPar = num % 2 == 0 //Par
const ehImpar = num % 2 == 1 //Impar

//IF = SE - ELSE = SENÃOimparOu
if (ehImpar) {
  console.log("o número é Par")
} else {
  console.log("o número é Impar")

}


console.log(ehPar)
console.log(ehImpar)

//console.log(idadeAtual+ "anos")



console.log(DadosPessoais)



//console.log(pet)
//console.log(nome)
//console.log(PI)


//*CRIE UNA VARIÁVEL PARA CADA SITUAÇÃO*/
//passatempo;
//cidade;
//preçoDolar;
//animalEstimação;
//estaSolteira= false ou true;
//todosOsDados(concatenar)

//const passatempo = "Assistir";
//const cidade = "Curitiba";
//const preçoDolar = 5.12;
//const animalEstimação = "Gato";
//const estaSolteira = false;
//const todosOsDados = passatempo + " " + cidade + " " + preçoDolar + " " + animalEstimação + " " + estaSolteira;

//console.log(passatempo + " " + cidade + " " + preçoDolar + " " + animalEstimação + " " + estaSolteira);

//console.log(todosOsDados);
