//OBJETIVO
/**
 * CRIAR VARIAVEIS E USÁ-LA PARA MODIFICAR A DOM
 */
const titulo = document.getElementById("titulo");
const paragrafo = document.getElementById("paragrafo");

//MINHAS VARIÁVEIS
const novoTitulo = "Título Modificado";
const novoParagrafo = "Parágrafo Modificado";

titulo.innerText = novoTitulo;
paragrafo.innerText = novoParagrafo;



//ARRAYS SÃO ORGANIZADOS POR ÍNDICES (A PARTIR DO ZERO)
const roupa = `camisa`
const roupas = ["camiseta", "calça", "meias", "sapato", "shorts", "blusa", "vestido", "chapéu", "moletom", "bermuda"];
// INDICES:         0         1       2        3
const precos = [50, 100, 20, 80, 30, 40, 60, 70, 90, 110];
const idades = [15, 16, 17, 18, 69, 20, 29, 10, 23, 24];
const misto = [15, "camiseta", true, "sapato", false, "shorts", "blusa", "vestido", "chapéu", "moletom"];
const comida = ["arroz", "feijão", "batata", "macarrão", "carne", "frango", "peixe", "pepino", "cenoura", "alface"];
//ACESSAR UM ELEMENTO DO ARRAY
//console.log(roupa)
//console.log (roupas)
//console.log (idades)
//console.log (misto)
//console.log (comida)
//console.log(comida [1])
//console.log (roupas [2])
//console.log (idades [0])
//console.log(misto [3])
//console.log(comida [2])
//console.log (idades [3])
//console.log(misto [9])

for (var i = 0; i <= 9; i++) {
  //lógica
  console.log(roupas[i])
}
for (var j = 0; j <= 9; j++) {
  console.log(precos[j])
}

