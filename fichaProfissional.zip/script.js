// VALORES DO HTML ESTÁTICO
const nome = document.getElementById('nome');
const sobrenome = document.getElementById('sobrenome');
const Idade = document.getElementById('idade');
const CGM = document.getElementById('cgm');
const Email = document.getElementById('email');

// VALORES DE VARIÁVEIS
const novoNome = "Letícia";
const novoSobrenome = "Oliveira";
const novaIdade = "17";
const novoCGM = "171852963";
const novoEmail = "leticia.oliveiradlmc@gmail.com";

// NOVOS VALORES ATRIBUÍDOS DE FORMA DINÂMICA
nome.innerHTML = novoNome;
sobrenome.innerHTML = novoSobrenome;
idade.innerHTML = novaIdade;
cgm.innerHTML = novoCGM;
email.innerHTML = novoEmail;                                                                                                                                                      